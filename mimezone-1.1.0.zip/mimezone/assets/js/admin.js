/**
 * MimeZone — settings screen behaviour.
 *
 * Plain DOM, no dependencies: the screen only needs a filter and a way to
 * select what is currently visible.
 */
( function () {
	'use strict';

	var root = document.querySelector( '.mimezone' );

	if ( ! root ) {
		return;
	}

	var search = root.querySelector( '.mimezone__search' );
	var counter = root.querySelector( '.mimezone__count' );
	var terms = Array.prototype.slice.call( root.querySelectorAll( '.mimezone__type' ) );
	var groups = Array.prototype.slice.call( root.querySelectorAll( '.mimezone__group' ) );
	var toggles = Array.prototype.slice.call( root.querySelectorAll( '.mimezone__toggle' ) );

	function checkboxes() {
		return terms
			.map( function ( term ) {
				return term.querySelector( 'input[type="checkbox"]' );
			} )
			.filter( Boolean );
	}

	function visibleTerms() {
		return terms.filter( function ( term ) {
			return ! term.classList.contains( 'is-hidden' );
		} );
	}

	function updateCounter() {
		if ( ! counter ) {
			return;
		}

		var selected = checkboxes().filter( function ( box ) {
			return box.checked;
		} ).length;

		counter.textContent =
			selected + ' selected · ' + visibleTerms().length + ' shown';
	}

	function applyFilter() {
		var query = ( search && search.value ? search.value : '' ).trim().toLowerCase();

		terms.forEach( function ( term ) {
			var haystack = ( term.getAttribute( 'data-term' ) || '' ).toLowerCase();
			var match = '' === query || haystack.indexOf( query ) !== -1;

			term.classList.toggle( 'is-hidden', ! match );
		} );

		groups.forEach( function ( group ) {
			var shown = group.querySelectorAll( '.mimezone__type:not(.is-hidden)' ).length;

			group.classList.toggle( 'is-hidden', 0 === shown );
		} );

		updateCounter();
	}

	if ( search ) {
		search.addEventListener( 'input', applyFilter );
	}

	checkboxes().forEach( function ( box ) {
		box.addEventListener( 'change', updateCounter );
	} );

	toggles.forEach( function ( button ) {
		button.addEventListener( 'click', function () {
			var state = '1' === button.getAttribute( 'data-select' );

			visibleTerms().forEach( function ( term ) {
				var box = term.querySelector( 'input[type="checkbox"]' );

				if ( box && box.checked !== state ) {
					box.checked = state;
				}
			} );

			updateCounter();
		} );
	} );

	updateCounter();
}() );
