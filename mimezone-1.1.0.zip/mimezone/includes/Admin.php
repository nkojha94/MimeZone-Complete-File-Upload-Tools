<?php
/**
 * Admin integration.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Small admin touches: the settings link and the screen's assets.
 */
final class Admin {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'plugin_action_links_' . plugin_basename( MIMEZONE_FILE ), array( $this, 'action_links' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Add a Settings link to the plugins list row.
	 *
	 * @param string[] $links Existing links.
	 * @return string[]
	 */
	public function action_links( $links ) {
		$links[] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'options-general.php?page=' . Settings::PAGE ) ),
			esc_html__( 'Settings', 'upload-anything' )
		);

		return $links;
	}

	/**
	 * Load the screen's assets, on that screen only.
	 *
	 * @param string $hook_suffix Current admin page.
	 * @return void
	 */
	public function enqueue( $hook_suffix ) {
		if ( 'settings_page_' . Settings::PAGE !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'mimezone-admin',
			MIMEZONE_URL . 'assets/css/admin.css',
			array(),
			MIMEZONE_VERSION
		);

		wp_enqueue_script(
			'mimezone-admin',
			MIMEZONE_URL . 'assets/js/admin.js',
			array(),
			MIMEZONE_VERSION,
			true
		);
	}
}
