<?php
/**
 * WP-CLI commands.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manage the allowed file types from the command line.
 *
 * @when after_wp_load
 */
final class CLI {

	/**
	 * Register the command namespace.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! class_exists( '\WP_CLI' ) ) {
			return;
		}

		\WP_CLI::add_command( 'mimezone', $this );
	}

	/**
	 * Show the current configuration.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mimezone status
	 *
	 * @return void
	 */
	public function status() {
		$settings = Options::all();

		\WP_CLI::log( 'Extra types: ' . ( $settings['enabled'] ? 'enabled' : 'disabled' ) );
		\WP_CLI::log( 'Required capability: ' . $settings['capability'] );
		\WP_CLI::log( 'Trusted mode: ' . ( $settings['trusted_mode'] ? 'on' : 'off' ) );
		\WP_CLI::log( 'Selected types: ' . count( $settings['types'] ) );
		\WP_CLI::log( 'Custom types: ' . count( $settings['custom_types'] ) );
	}

	/**
	 * List every file type the plugin knows about.
	 *
	 * ## OPTIONS
	 *
	 * [--enabled]
	 * : Only list the types that are currently enabled.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mimezone types --enabled
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Flags.
	 * @return void
	 */
	public function types( $args, $assoc_args ) {
		unset( $args );

		$settings = Options::all();
		$only     = isset( $assoc_args['enabled'] );
		$rows     = array();

		foreach ( File_Types::extensions() as $extension ) {
			$enabled = in_array( $extension, $settings['types'], true ) || isset( $settings['custom_types'][ $extension ] );

			if ( $only && ! $enabled ) {
				continue;
			}

			$rows[] = array(
				'extension' => $extension,
				'mime'      => File_Types::mime( $extension ),
				'risk'      => File_Types::risk( $extension ),
				'enabled'   => $enabled ? 'yes' : 'no',
			);
		}

		\WP_CLI\Utils\format_items( 'table', $rows, array( 'extension', 'mime', 'risk', 'enabled' ) );
	}

	/**
	 * Enable one or more file types.
	 *
	 * ## OPTIONS
	 *
	 * <extension>...
	 * : One or more extensions, with or without a leading dot.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mimezone enable svg avif fig
	 *
	 * @param string[] $args Extensions.
	 * @return void
	 */
	public function enable( $args ) {
		$this->toggle( $args, true );
	}

	/**
	 * Disable one or more file types.
	 *
	 * ## OPTIONS
	 *
	 * <extension>...
	 * : One or more extensions, with or without a leading dot.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mimezone disable svg
	 *
	 * @param string[] $args Extensions.
	 * @return void
	 */
	public function disable( $args ) {
		$this->toggle( $args, false );
	}

	/**
	 * Add or remove extensions from the saved list.
	 *
	 * @param string[] $extensions Extensions as typed on the command line.
	 * @param bool     $enable     Whether to add or remove.
	 * @return void
	 */
	private function toggle( $extensions, $enable ) {
		$settings = Options::all();
		$types    = $settings['types'];
		$changed  = 0;

		foreach ( (array) $extensions as $extension ) {
			$extension = strtolower( ltrim( trim( (string) $extension ), '.' ) );

			if ( File_Types::is_blocked( $extension ) ) {
				/* translators: %s: file extension, without the dot. */
				\WP_CLI::warning( sprintf( __( '.%s is blocked and cannot be enabled.', 'upload-anything' ), $extension ) );
				continue;
			}

			if ( ! File_Types::is_known( $extension ) ) {
				/* translators: %s: file extension, without the dot. */
				\WP_CLI::warning( sprintf( __( '.%s is not a known type. Add it on the settings screen first.', 'upload-anything' ), $extension ) );
				continue;
			}

			if ( $enable && ! in_array( $extension, $types, true ) ) {
				$types[] = $extension;
				++$changed;
			} elseif ( ! $enable && in_array( $extension, $types, true ) ) {
				$types = array_values( array_diff( $types, array( $extension ) ) );
				++$changed;
			}
		}

		if ( 0 === $changed ) {
			\WP_CLI::log( 'Nothing to change.' );

			return;
		}

		$settings['types'] = $types;
		Options::update( $settings );

		/* translators: %d: number of file types changed. */
		\WP_CLI::success( sprintf( _n( '%d type updated.', '%d types updated.', $changed, 'upload-anything' ), $changed ) );
	}
}
