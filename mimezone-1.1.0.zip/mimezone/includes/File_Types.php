<?php
/**
 * File type catalog.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The file types the plugin can unlock.
 *
 * Extensions a web server can execute, or that can be used to reconfigure one,
 * are kept in BLOCKED and are never offered in the settings screen. They are
 * also filtered out again at upload time, so a stored option cannot re-enable
 * them: the deny list is code, not configuration.
 *
 * Types that a browser would render as live markup — HTML, JavaScript, CSS,
 * XML — are deliberately absent from the catalogue. They are byte-for-byte
 * interchangeable with code on the front end, so there is no setting under
 * which this plugin will hand them to `upload_mimes`.
 *
 * The risk level on each entry is what the settings screen advertises:
 *   safe   — offered to whoever the capability setting allows.
 *   review — the same, but the file is cleaned on the way in (SVG).
 */
final class File_Types {

	/**
	 * Extensions that stay locked no matter what the settings say.
	 *
	 * @var string[]
	 */
	const BLOCKED = array(
		'php',
		'php3',
		'php4',
		'php5',
		'php7',
		'php8',
		'phtml',
		'pht',
		'phar',
		'phps',
		'cgi',
		'pl',
		'py',
		'rb',
		'sh',
		'bash',
		'exe',
		'com',
		'bat',
		'cmd',
		'msi',
		'dll',
		'so',
		'jsp',
		'asp',
		'aspx',
		'shtml',
		'htaccess',
		'htpasswd',
		'ini',
		'env',
		'sql',
	);

	/**
	 * Extensions a browser executes or renders as live markup.
	 *
	 * A file saved with one of these extensions is served back as a document
	 * rather than as a download, so a single upload is enough to run script in
	 * an administrator's session. They are absent from the catalogue and are
	 * refused again here, which is what keeps trusted mode from reaching them.
	 *
	 * @var string[]
	 */
	const LIVE_MARKUP = array(
		'html',
		'htm',
		'xhtml',
		'xht',
		'js',
		'mjs',
		'cjs',
		'css',
		'xml',
		'xsl',
		'xslt',
		'svgz',
	);

	/**
	 * Groups, in the order they are shown.
	 *
	 * @var string[]
	 */
	const GROUPS = array( 'images', 'documents', 'archives', 'audio', 'video', 'fonts', 'design', 'data' );

	/**
	 * Known extensions.
	 *
	 * `mime` is what WordPress records for the upload, so it should be the value
	 * a browser or an OS would report rather than a guess. Types without a
	 * registered media type use application/octet-stream.
	 *
	 * @var array<string, array<string, string>>
	 */
	const TYPES = array(
		// Images.
		'svg'    => array(
			'mime'  => 'image/svg+xml',
			'group' => 'images',
			'risk'  => 'review',
		),
		'avif'   => array(
			'mime'  => 'image/avif',
			'group' => 'images',
			'risk'  => 'safe',
		),
		'webp'   => array(
			'mime'  => 'image/webp',
			'group' => 'images',
			'risk'  => 'safe',
		),
		'apng'   => array(
			'mime'  => 'image/apng',
			'group' => 'images',
			'risk'  => 'safe',
		),
		'ico'    => array(
			'mime'  => 'image/x-icon',
			'group' => 'images',
			'risk'  => 'safe',
		),
		'heic'   => array(
			'mime'  => 'image/heic',
			'group' => 'images',
			'risk'  => 'safe',
		),
		'heif'   => array(
			'mime'  => 'image/heif',
			'group' => 'images',
			'risk'  => 'safe',
		),
		'jxl'    => array(
			'mime'  => 'image/jxl',
			'group' => 'images',
			'risk'  => 'safe',
		),
		'tif'    => array(
			'mime'  => 'image/tiff',
			'group' => 'images',
			'risk'  => 'safe',
		),
		'tiff'   => array(
			'mime'  => 'image/tiff',
			'group' => 'images',
			'risk'  => 'safe',
		),

		// Documents.
		'doc'    => array(
			'mime'  => 'application/msword',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'docx'   => array(
			'mime'  => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'xls'    => array(
			'mime'  => 'application/vnd.ms-excel',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'xlsx'   => array(
			'mime'  => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'ppt'    => array(
			'mime'  => 'application/vnd.ms-powerpoint',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'pptx'   => array(
			'mime'  => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'odt'    => array(
			'mime'  => 'application/vnd.oasis.opendocument.text',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'ods'    => array(
			'mime'  => 'application/vnd.oasis.opendocument.spreadsheet',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'odp'    => array(
			'mime'  => 'application/vnd.oasis.opendocument.presentation',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'rtf'    => array(
			'mime'  => 'application/rtf',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'md'     => array(
			'mime'  => 'text/markdown',
			'group' => 'documents',
			'risk'  => 'safe',
		),
		'epub'   => array(
			'mime'  => 'application/epub+zip',
			'group' => 'documents',
			'risk'  => 'safe',
		),

		// Archives.
		'zip'    => array(
			'mime'  => 'application/zip',
			'group' => 'archives',
			'risk'  => 'safe',
		),
		'rar'    => array(
			'mime'  => 'application/vnd.rar',
			'group' => 'archives',
			'risk'  => 'safe',
		),
		'7z'     => array(
			'mime'  => 'application/x-7z-compressed',
			'group' => 'archives',
			'risk'  => 'safe',
		),
		'tar'    => array(
			'mime'  => 'application/x-tar',
			'group' => 'archives',
			'risk'  => 'safe',
		),
		'gz'     => array(
			'mime'  => 'application/gzip',
			'group' => 'archives',
			'risk'  => 'safe',
		),
		'tgz'    => array(
			'mime'  => 'application/gzip',
			'group' => 'archives',
			'risk'  => 'safe',
		),
		'bz2'    => array(
			'mime'  => 'application/x-bzip2',
			'group' => 'archives',
			'risk'  => 'safe',
		),

		// Audio.
		'mp3'    => array(
			'mime'  => 'audio/mpeg',
			'group' => 'audio',
			'risk'  => 'safe',
		),
		'wav'    => array(
			'mime'  => 'audio/wav',
			'group' => 'audio',
			'risk'  => 'safe',
		),
		'flac'   => array(
			'mime'  => 'audio/flac',
			'group' => 'audio',
			'risk'  => 'safe',
		),
		'm4a'    => array(
			'mime'  => 'audio/mp4',
			'group' => 'audio',
			'risk'  => 'safe',
		),
		'ogg'    => array(
			'mime'  => 'audio/ogg',
			'group' => 'audio',
			'risk'  => 'safe',
		),
		'opus'   => array(
			'mime'  => 'audio/opus',
			'group' => 'audio',
			'risk'  => 'safe',
		),
		'aiff'   => array(
			'mime'  => 'audio/aiff',
			'group' => 'audio',
			'risk'  => 'safe',
		),
		'midi'   => array(
			'mime'  => 'audio/midi',
			'group' => 'audio',
			'risk'  => 'safe',
		),

		// Video.
		'mp4'    => array(
			'mime'  => 'video/mp4',
			'group' => 'video',
			'risk'  => 'safe',
		),
		'webm'   => array(
			'mime'  => 'video/webm',
			'group' => 'video',
			'risk'  => 'safe',
		),
		'mov'    => array(
			'mime'  => 'video/quicktime',
			'group' => 'video',
			'risk'  => 'safe',
		),
		'mkv'    => array(
			'mime'  => 'video/x-matroska',
			'group' => 'video',
			'risk'  => 'safe',
		),
		'avi'    => array(
			'mime'  => 'video/x-msvideo',
			'group' => 'video',
			'risk'  => 'safe',
		),
		'm4v'    => array(
			'mime'  => 'video/mp4',
			'group' => 'video',
			'risk'  => 'safe',
		),
		'ogv'    => array(
			'mime'  => 'video/ogg',
			'group' => 'video',
			'risk'  => 'safe',
		),
		'wmv'    => array(
			'mime'  => 'video/x-ms-wmv',
			'group' => 'video',
			'risk'  => 'safe',
		),

		// Fonts.
		'woff'   => array(
			'mime'  => 'font/woff',
			'group' => 'fonts',
			'risk'  => 'safe',
		),
		'woff2'  => array(
			'mime'  => 'font/woff2',
			'group' => 'fonts',
			'risk'  => 'safe',
		),
		'ttf'    => array(
			'mime'  => 'font/ttf',
			'group' => 'fonts',
			'risk'  => 'safe',
		),
		'otf'    => array(
			'mime'  => 'font/otf',
			'group' => 'fonts',
			'risk'  => 'safe',
		),
		'eot'    => array(
			'mime'  => 'application/vnd.ms-fontobject',
			'group' => 'fonts',
			'risk'  => 'safe',
		),

		// Design files.
		'psd'    => array(
			'mime'  => 'image/vnd.adobe.photoshop',
			'group' => 'design',
			'risk'  => 'safe',
		),
		'ai'     => array(
			'mime'  => 'application/postscript',
			'group' => 'design',
			'risk'  => 'safe',
		),
		'eps'    => array(
			'mime'  => 'application/postscript',
			'group' => 'design',
			'risk'  => 'safe',
		),
		'indd'   => array(
			'mime'  => 'application/x-indesign',
			'group' => 'design',
			'risk'  => 'safe',
		),
		'sketch' => array(
			'mime'  => 'application/octet-stream',
			'group' => 'design',
			'risk'  => 'safe',
		),
		'fig'    => array(
			'mime'  => 'application/octet-stream',
			'group' => 'design',
			'risk'  => 'safe',
		),
		'xd'     => array(
			'mime'  => 'application/octet-stream',
			'group' => 'design',
			'risk'  => 'safe',
		),

		// Data.
		'json'   => array(
			'mime'  => 'application/json',
			'group' => 'data',
			'risk'  => 'safe',
		),
		'yml'    => array(
			'mime'  => 'text/yaml',
			'group' => 'data',
			'risk'  => 'safe',
		),
		'yaml'   => array(
			'mime'  => 'text/yaml',
			'group' => 'data',
			'risk'  => 'safe',
		),
		'csv'    => array(
			'mime'  => 'text/csv',
			'group' => 'data',
			'risk'  => 'safe',
		),
		'log'    => array(
			'mime'  => 'text/plain',
			'group' => 'data',
			'risk'  => 'safe',
		),
	);

	/**
	 * Every extension the plugin knows about, including custom ones.
	 *
	 * @return string[]
	 */
	public static function extensions() {
		return array_values( array_unique( array_merge( array_keys( self::TYPES ), array_keys( self::custom() ) ) ) );
	}

	/**
	 * Known and custom types grouped for the settings screen.
	 *
	 * @return array<string, array<string, array<string, string>>>
	 */
	public static function grouped() {
		$grouped = array_fill_keys( self::GROUPS, array() );

		foreach ( self::TYPES as $extension => $data ) {
			if ( isset( $grouped[ $data['group'] ] ) ) {
				$grouped[ $data['group'] ][ $extension ] = $data;
			}
		}

		return $grouped;
	}

	/**
	 * Translated group name.
	 *
	 * @param string $group Group key.
	 * @return string
	 */
	public static function group_label( $group ) {
		switch ( $group ) {
			case 'images':
				return __( 'Images', 'upload-anything' );
			case 'documents':
				return __( 'Documents', 'upload-anything' );
			case 'archives':
				return __( 'Archives', 'upload-anything' );
			case 'audio':
				return __( 'Audio', 'upload-anything' );
			case 'video':
				return __( 'Video', 'upload-anything' );
			case 'fonts':
				return __( 'Fonts', 'upload-anything' );
			case 'design':
				return __( 'Design files', 'upload-anything' );
			case 'data':
				return __( 'Data files', 'upload-anything' );
		}

		return $group;
	}

	/**
	 * Whether an extension is on the deny list.
	 *
	 * @param string $extension Lowercase extension without a dot.
	 * @return bool
	 */
	public static function is_blocked( $extension ) {
		$extension = strtolower( (string) $extension );

		return in_array( $extension, self::BLOCKED, true ) || in_array( $extension, self::LIVE_MARKUP, true );
	}

	/**
	 * Whether the extension is known, either built in or custom.
	 *
	 * @param string $extension Lowercase extension without a dot.
	 * @return bool
	 */
	public static function is_known( $extension ) {
		$extension = strtolower( (string) $extension );

		return isset( self::TYPES[ $extension ] ) || isset( self::custom()[ $extension ] );
	}

	/**
	 * Mime type recorded for an extension.
	 *
	 * @param string $extension Lowercase extension without a dot.
	 * @return string Empty string when the extension is unknown.
	 */
	public static function mime( $extension ) {
		$extension = strtolower( (string) $extension );

		if ( isset( self::TYPES[ $extension ] ) ) {
			return self::TYPES[ $extension ]['mime'];
		}

		$custom = self::custom();

		return isset( $custom[ $extension ] ) ? $custom[ $extension ] : '';
	}

	/**
	 * Short label for an extension.
	 *
	 * @param string $extension Lowercase extension without a dot.
	 * @return string
	 */
	public static function label( $extension ) {
		$labels = array(
			'svg'    => 'SVG',
			'avif'   => 'AVIF',
			'webp'   => 'WebP',
			'heic'   => 'HEIC',
			'heif'   => 'HEIF',
			'jxl'    => 'JPEG XL',
			'psd'    => 'Photoshop',
			'ai'     => 'Illustrator',
			'indd'   => 'InDesign',
			'sketch' => 'Sketch',
			'fig'    => 'Figma',
			'xd'     => 'XD',
			'json'   => 'JSON',
			'yml'    => 'YAML',
			'yaml'   => 'YAML',
		);

		$extension = strtolower( (string) $extension );

		return isset( $labels[ $extension ] ) ? $labels[ $extension ] : strtoupper( $extension );
	}

	/**
	 * Risk level for an extension.
	 *
	 * @param string $extension Lowercase extension without a dot.
	 * @return string Either safe or review.
	 */
	public static function risk( $extension ) {
		$extension = strtolower( (string) $extension );

		if ( isset( self::TYPES[ $extension ]['risk'] ) ) {
			return self::TYPES[ $extension ]['risk'];
		}

		return 'safe';
	}

	/**
	 * Types added by the site owner, keyed by extension.
	 *
	 * @return array<string, string>
	 */
	private static function custom() {
		return Options::custom_types();
	}
}
