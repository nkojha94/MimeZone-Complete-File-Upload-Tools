<?php
/**
 * Activation routine.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prepares the option on activation.
 */
final class Installer {

	/**
	 * Write the defaults, unless the site already has settings.
	 *
	 * Activating twice, or reactivating after an update, must not discard a
	 * configuration that took time to put together.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( false === get_option( Options::OPTION, false ) ) {
			add_option( Options::OPTION, Options::defaults() );
		}
	}
}
