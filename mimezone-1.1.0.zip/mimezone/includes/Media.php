<?php
/**
 * Media library integration.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Makes SVG attachments look like images in the media library.
 *
 * WordPress lists an SVG as a generic file because it never generated image
 * metadata for it. The editor's image block still inserts it correctly, but the
 * grid shows no preview. Reporting the file itself as the full size fixes that
 * without writing thumbnails the site would then have to keep in sync.
 */
final class Media {

	/**
	 * Attachment meta key holding the parsed SVG dimensions.
	 *
	 * @var string
	 */
	const SIZE_META = '_mimezone_svg_size';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'wp_prepare_attachment_for_js', array( $this, 'prepare_svg' ), 10, 2 );
	}

	/**
	 * Describe an SVG as a displayable image.
	 *
	 * @param array<string, mixed> $response   Attachment data for the media modal.
	 * @param \WP_Post             $attachment Attachment post.
	 * @return array<string, mixed>
	 */
	public function prepare_svg( $response, $attachment ) {
		if ( ! is_array( $response ) || ! isset( $response['mime'] ) || 'image/svg+xml' !== $response['mime'] ) {
			return $response;
		}

		if ( ! empty( $response['sizes'] ) ) {
			return $response;
		}

		$url = isset( $response['url'] ) && '' !== $response['url']
			? (string) $response['url']
			: (string) wp_get_attachment_url( $attachment->ID );

		if ( '' === $url ) {
			return $response;
		}

		$size = $this->dimensions( $attachment );

		$response['type']    = 'image';
		$response['subtype'] = 'svg+xml';
		$response['icon']    = $url;
		$response['sizes']   = array(
			'full' => array(
				'url'         => $url,
				'width'       => $size[0],
				'height'      => $size[1],
				'orientation' => $size[0] >= $size[1] ? 'landscape' : 'portrait',
			),
		);

		return $response;
	}

	/**
	 * Width and height from the SVG root, cached in attachment meta.
	 *
	 * @param \WP_Post $attachment Attachment post.
	 * @return int[] Width and height; zero when the file does not say.
	 */
	private function dimensions( $attachment ) {
		$id   = isset( $attachment->ID ) ? (int) $attachment->ID : 0;
		$size = $id ? get_post_meta( $id, self::SIZE_META, true ) : '';

		if ( is_array( $size ) && 2 === count( $size ) ) {
			return array( (int) $size[0], (int) $size[1] );
		}

		$size = array( 0, 0 );
		$file = $id ? (string) get_attached_file( $id ) : '';

		if ( '' !== $file && is_readable( $file ) ) {
			$head = file_get_contents( $file, false, null, 0, 2048 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading the local attachment.

			if ( is_string( $head ) && preg_match( '/<svg\b[^>]*>/i', $head, $open ) ) {
				$size = self::parse_dimensions( $open[0] );
			}
		}

		if ( $id ) {
			update_post_meta( $id, self::SIZE_META, $size );
		}

		return $size;
	}

	/**
	 * Read width and height from an opening svg tag.
	 *
	 * Falls back to the viewBox, which is what most editors write instead of
	 * absolute dimensions.
	 *
	 * @param string $tag Opening tag.
	 * @return int[]
	 */
	private static function parse_dimensions( $tag ) {
		$width  = 0;
		$height = 0;

		if ( preg_match( '/\swidth\s*=\s*["\']([0-9.]+)(?:px)?["\']/i', $tag, $match ) ) {
			$width = (int) round( (float) $match[1] );
		}

		if ( preg_match( '/\sheight\s*=\s*["\']([0-9.]+)(?:px)?["\']/i', $tag, $match ) ) {
			$height = (int) round( (float) $match[1] );
		}

		if ( ( 0 === $width || 0 === $height ) && preg_match( '/\sviewBox\s*=\s*["\']\s*[-0-9.]+[,\s]+[-0-9.]+[,\s]+([0-9.]+)[,\s]+([0-9.]+)/i', $tag, $match ) ) {
			$width  = (int) round( (float) $match[1] );
			$height = (int) round( (float) $match[2] );
		}

		return array( $width, $height );
	}
}
