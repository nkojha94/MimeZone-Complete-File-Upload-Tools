<?php
/**
 * Settings storage.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads and validates the plugin option.
 *
 * Everything that decides "may this user upload this extension" lives here so
 * the upload filters and the admin screens cannot drift apart.
 */
final class Options {

	/**
	 * Option name.
	 *
	 * @var string
	 */
	const OPTION = 'mimezone_settings';

	/**
	 * Capabilities the site owner can hand out.
	 *
	 * @var string[]
	 */
	const CAPABILITIES = array( 'manage_options', 'edit_others_posts', 'upload_files' );

	/**
	 * Types enabled on activation.
	 *
	 * Chosen so a fresh install immediately covers the requests that bring
	 * people to a plugin like this, without unlocking anything executable.
	 *
	 * @var string[]
	 */
	const DEFAULT_TYPES = array(
		'svg',
		'avif',
		'webp',
		'ico',
		'apng',
		'heic',
		'flac',
		'm4a',
		'ogg',
		'opus',
		'webm',
		'mov',
		'mkv',
		'woff',
		'woff2',
		'ttf',
		'otf',
		'rar',
		'7z',
		'tar',
		'gz',
		'json',
		'md',
		'epub',
	);

	/**
	 * Default settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults() {
		return array(
			'enabled'      => true,
			'capability'   => 'manage_options',
			'trusted_mode' => false,
			'types'        => self::DEFAULT_TYPES,
			'custom_types' => array(),
		);
	}

	/**
	 * All settings, merged over the defaults.
	 *
	 * @return array<string, mixed>
	 */
	public static function all() {
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		$merged = array_merge( self::defaults(), array_intersect_key( $stored, self::defaults() ) );

		$merged['enabled']      = (bool) $merged['enabled'];
		$merged['trusted_mode'] = (bool) $merged['trusted_mode'];
		$merged['capability']   = in_array( $merged['capability'], self::CAPABILITIES, true )
			? $merged['capability']
			: 'manage_options';
		$merged['types']        = self::normalise_types( $merged['types'] );
		$merged['custom_types'] = self::normalise_custom( $merged['custom_types'] );

		return $merged;
	}

	/**
	 * A single setting.
	 *
	 * @param string $key Setting key.
	 * @return mixed Null when the key is unknown.
	 */
	public static function get( $key ) {
		$settings = self::all();

		return array_key_exists( $key, $settings ) ? $settings[ $key ] : null;
	}

	/**
	 * Save settings.
	 *
	 * @param array<string, mixed> $values Raw values.
	 * @return void
	 */
	public static function update( array $values ) {
		update_option( self::OPTION, self::sanitize( $values ) );
	}

	/**
	 * Validate submitted settings.
	 *
	 * Also used as the sanitize callback for register_setting(), which is why it
	 * reports what it dropped instead of silently trimming the submission.
	 *
	 * @param mixed $value Submitted value.
	 * @return array<string, mixed>
	 */
	public static function sanitize( $value ) {
		$value = is_array( $value ) ? $value : array();

		$clean = array(
			'enabled'      => ! empty( $value['enabled'] ),
			'capability'   => isset( $value['capability'] ) && in_array( $value['capability'], self::CAPABILITIES, true )
				? $value['capability']
				: 'manage_options',
			'trusted_mode' => ! empty( $value['trusted_mode'] ),
			'types'        => array(),
			'custom_types' => array(),
		);

		$submitted = isset( $value['types'] ) && is_array( $value['types'] ) ? $value['types'] : array();
		$seen      = array();

		foreach ( $submitted as $extension ) {
			$extension = strtolower( trim( (string) $extension ) );

			if ( '' === $extension || isset( $seen[ $extension ] ) ) {
				continue;
			}

			$seen[ $extension ] = true;

			if ( File_Types::is_blocked( $extension ) ) {
				/* translators: %s: file extension, without the dot. */
				self::reject( sprintf( __( '.%s is blocked because a server can execute it or use it to change its own configuration.', 'upload-anything' ), $extension ) );
				continue;
			}

			if ( ! File_Types::is_known( $extension ) ) {
				/* translators: %s: file extension, without the dot. */
				self::reject( sprintf( __( '.%s is not a type this plugin knows about, so it was ignored.', 'upload-anything' ), $extension ) );
				continue;
			}

			$clean['types'][] = $extension;
		}

		$clean['types']        = array_values( array_unique( $clean['types'] ) );
		$clean['custom_types'] = self::parse_custom( isset( $value['custom_types'] ) ? $value['custom_types'] : array() );

		return $clean;
	}

	/**
	 * Types enabled and available to the current user.
	 *
	 * @return string[]
	 */
	public static function enabled_types() {
		$settings = self::all();

		if ( ! $settings['enabled'] ) {
			return array();
		}

		$types = array_merge( $settings['types'], array_keys( $settings['custom_types'] ) );

		return array_values(
			array_filter(
				array_unique( $types ),
				static function ( $extension ) {
					return ! File_Types::is_blocked( $extension );
				}
			)
		);
	}

	/**
	 * Enabled types the current user is allowed to upload.
	 *
	 * @return string[]
	 */
	public static function types_for_current_user() {
		if ( ! self::user_can_upload_extra() ) {
			return array();
		}

		return self::enabled_types();
	}

	/**
	 * Whether a given extension may be uploaded by the current user.
	 *
	 * @param string $extension Extension without a dot.
	 * @return bool
	 */
	public static function can_upload( $extension ) {
		$extension = strtolower( (string) $extension );

		if ( '' === $extension || File_Types::is_blocked( $extension ) ) {
			return false;
		}

		if ( in_array( $extension, self::types_for_current_user(), true ) ) {
			return true;
		}

		return self::is_trusted() && ! File_Types::is_known( $extension );
	}

	/**
	 * Whether the option is switched on for the current user.
	 *
	 * @return bool
	 */
	public static function user_can_upload_extra() {
		$settings = self::all();

		if ( empty( $settings['enabled'] ) ) {
			return false;
		}

		return current_user_can( $settings['capability'] );
	}

	/**
	 * Whether trusted mode is on for the current user.
	 *
	 * Trusted mode is administrator-only on purpose; it skips the type check, so
	 * it should never be reachable from an editor account.
	 *
	 * @return bool
	 */
	public static function is_trusted() {
		$settings = self::all();

		return ! empty( $settings['trusted_mode'] ) && current_user_can( 'manage_options' );
	}

	/**
	 * Custom types, keyed by extension.
	 *
	 * @return array<string, string>
	 */
	public static function custom_types() {
		$settings = self::all();

		return $settings['custom_types'];
	}

	/**
	 * Read the custom type textarea into an extension to mime map.
	 *
	 * Accepts one entry per line, either `ext` or `ext: mime/type`.
	 *
	 * @param mixed $value Textarea contents, or an already parsed map.
	 * @return array<string, string>
	 */
	private static function parse_custom( $value ) {
		if ( is_array( $value ) ) {
			return self::normalise_custom( $value );
		}

		$parsed = array();
		$lines  = preg_split( '/\r\n|\r|\n/', (string) $value );

		foreach ( (array) $lines as $line ) {
			$line = trim( $line );

			if ( '' === $line ) {
				continue;
			}

			$parts     = preg_split( '/[\s:]+/', $line, 2 );
			$extension = strtolower( (string) $parts[0] );
			$mime      = isset( $parts[1] ) ? trim( $parts[1] ) : '';

			$parsed[ $extension ] = $mime;
		}

		return self::normalise_custom( $parsed );
	}

	/**
	 * Keep only well formed, non-blocked custom types.
	 *
	 * @param mixed $value Map or list of custom types.
	 * @return array<string, string>
	 */
	private static function normalise_custom( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean = array();

		foreach ( $value as $extension => $mime ) {
			// A list rather than a map: the extension was supplied as the value.
			if ( is_int( $extension ) ) {
				$extension = $mime;
				$mime      = '';
			}

			$extension = strtolower( trim( (string) $extension ) );
			$mime      = trim( (string) $mime );

			if ( ! preg_match( '/^[a-z0-9]{1,10}$/', $extension ) || File_Types::is_blocked( $extension ) ) {
				continue;
			}

			if ( ! preg_match( '~^[a-z0-9][a-z0-9!#$&^_.+-]*/[a-z0-9][a-z0-9!#$&^_.+-]*$~i', $mime ) ) {
				$mime = 'application/octet-stream';
			}

			$clean[ $extension ] = strtolower( $mime );
		}

		return $clean;
	}

	/**
	 * Keep only usable, non-blocked extension names.
	 *
	 * @param mixed $value Stored value.
	 * @return string[]
	 */
	private static function normalise_types( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean = array();

		foreach ( $value as $extension ) {
			$extension = strtolower( trim( (string) $extension ) );

			if ( '' === $extension || File_Types::is_blocked( $extension ) ) {
				continue;
			}

			$clean[] = $extension;
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Report a rejected value on the settings screen.
	 *
	 * @param string $message Already translated and formatted message.
	 * @return void
	 */
	private static function reject( $message ) {
		add_settings_error( self::OPTION, 'mimezone-rejected', $message, 'warning' );
	}
}
