<?php
/**
 * Plugin container.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Boots the plugin's services on their hooks.
 */
final class Plugin {

	/**
	 * Shared instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Retrieve the shared instance.
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register every service.
	 *
	 * @return void
	 */
	public function boot() {
		// Translations are loaded by WordPress from the plugin's languages
		// directory, so load_plugin_textdomain() is not called here.
		( new Uploads() )->register();
		( new Media() )->register();

		if ( is_admin() ) {
			( new Admin() )->register();
			( new Settings() )->register();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			( new CLI() )->register();
		}
	}
}
