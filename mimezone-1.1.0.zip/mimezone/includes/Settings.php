<?php
/**
 * Settings screen.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The one screen this plugin adds.
 *
 * It is deliberately an administrator screen: it decides which file types a
 * server will accept, which is a site-wide security decision rather than an
 * editing preference.
 */
final class Settings {

	/**
	 * Screen slug.
	 *
	 * @var string
	 */
	const PAGE = 'mimezone';

	/**
	 * Settings API group.
	 *
	 * @var string
	 */
	const GROUP = 'mimezone';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'add_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Add the screen under Settings.
	 *
	 * @return void
	 */
	public function add_page() {
		add_options_page(
			__( 'MimeZone', 'upload-anything' ),
			__( 'MimeZone', 'upload-anything' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render' )
		);
	}

	/**
	 * Register the option with the Settings API.
	 *
	 * @return void
	 */
	public function register_settings() {
		register_setting(
			self::GROUP,
			Options::OPTION,
			array(
				'type'              => 'array',
				'default'           => Options::defaults(),
				'sanitize_callback' => array( Options::class, 'sanitize' ),
				'show_in_rest'      => false,
			)
		);
	}

	/**
	 * Draw the screen.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = Options::all();
		$selected = $settings['types'];
		$custom   = '';

		foreach ( $settings['custom_types'] as $extension => $mime ) {
			$custom .= $extension . ': ' . $mime . "\n";
		}
		?>
		<div class="wrap mimezone">
			<div class="mimezone__header">
				<img
					class="mimezone__mark"
					src="<?php echo esc_url( MIMEZONE_URL . 'assets/images/icon.svg' ); ?>"
					alt=""
					width="48"
					height="48"
					decoding="async"
				/>
				<div class="mimezone__intro">
					<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

					<p class="mimezone__lede">
						<?php esc_html_e( 'WordPress accepts a short list of file types. Everything below is an addition to that list, scoped to the roles you choose here.', 'upload-anything' ); ?>
					</p>
				</div>
			</div>

			<?php settings_errors( Options::OPTION ); ?>

			<form method="post" action="options.php">
				<?php settings_fields( self::GROUP ); ?>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><?php esc_html_e( 'Status', 'upload-anything' ); ?></th>
							<td>
								<fieldset>
									<legend class="screen-reader-text"><?php esc_html_e( 'Whether extra file types are allowed', 'upload-anything' ); ?></legend>
									<label for="mimezone-enabled">
										<input
											type="checkbox"
											id="mimezone-enabled"
											name="<?php echo esc_attr( Options::OPTION ); ?>[enabled]"
											value="1"
											<?php checked( $settings['enabled'] ); ?>
										/>
										<?php esc_html_e( 'Allow the file types selected below', 'upload-anything' ); ?>
									</label>
								</fieldset>
							</td>
						</tr>

						<tr>
							<th scope="row">
								<label for="mimezone-capability"><?php esc_html_e( 'Who can upload them', 'upload-anything' ); ?></label>
							</th>
							<td>
								<select id="mimezone-capability" name="<?php echo esc_attr( Options::OPTION ); ?>[capability]">
									<?php foreach ( $this->capability_choices() as $capability => $label ) : ?>
										<option value="<?php echo esc_attr( $capability ); ?>" <?php selected( $settings['capability'], $capability ); ?>>
											<?php echo esc_html( $label ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description">
									<?php esc_html_e( 'Types a browser runs as code — HTML, JavaScript, CSS, XML — are not offered at all, for any role. Trusted mode stays administrator-only.', 'upload-anything' ); ?>
								</p>
							</td>
						</tr>

						<tr>
							<th scope="row"><?php esc_html_e( 'Trusted mode', 'upload-anything' ); ?></th>
							<td>
								<fieldset>
									<legend class="screen-reader-text"><?php esc_html_e( 'Whether unknown file types are accepted', 'upload-anything' ); ?></legend>
									<label for="mimezone-trusted">
										<input
											type="checkbox"
											id="mimezone-trusted"
											name="<?php echo esc_attr( Options::OPTION ); ?>[trusted_mode]"
											value="1"
											<?php checked( $settings['trusted_mode'] ); ?>
										/>
										<?php esc_html_e( 'Accept file types that are not in the list, for administrators', 'upload-anything' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'Useful when a client keeps sending a format nobody anticipated. Files a server can execute are still refused.', 'upload-anything' ); ?>
									</p>
								</fieldset>
							</td>
						</tr>
					</tbody>
				</table>

				<h2 class="mimezone__heading"><?php esc_html_e( 'File types', 'upload-anything' ); ?></h2>

				<div class="mimezone__toolbar">
					<label class="screen-reader-text" for="mimezone-search">
						<?php esc_html_e( 'Filter file types', 'upload-anything' ); ?>
					</label>
					<input
						type="search"
						id="mimezone-search"
						class="mimezone__search"
						placeholder="<?php esc_attr_e( 'Filter by extension or type…', 'upload-anything' ); ?>"
					/>
					<span class="mimezone__count" aria-live="polite"></span>
					<button type="button" class="button mimezone__toggle" data-select="1">
						<?php esc_html_e( 'Select all visible', 'upload-anything' ); ?>
					</button>
					<button type="button" class="button mimezone__toggle" data-select="0">
						<?php esc_html_e( 'Clear visible', 'upload-anything' ); ?>
					</button>
				</div>

				<?php foreach ( File_Types::grouped() as $group => $types ) : ?>
					<?php if ( empty( $types ) ) : ?>
						<?php continue; ?>
					<?php endif; ?>

					<section class="mimezone__group" data-group="<?php echo esc_attr( $group ); ?>">
						<h3 class="mimezone__group-title"><?php echo esc_html( File_Types::group_label( $group ) ); ?></h3>

						<div class="mimezone__grid">
							<?php foreach ( $types as $extension => $type ) : ?>
								<label
									class="mimezone__type mimezone__type--<?php echo esc_attr( $type['risk'] ); ?>"
									data-term="<?php echo esc_attr( $extension . ' ' . $type['mime'] . ' ' . $type['group'] ); ?>"
								>
									<input
										type="checkbox"
										name="<?php echo esc_attr( Options::OPTION ); ?>[types][]"
										value="<?php echo esc_attr( $extension ); ?>"
										<?php checked( in_array( $extension, $selected, true ) ); ?>
									/>
									<span class="mimezone__ext">.<?php echo esc_html( $extension ); ?></span>
									<span class="mimezone__mime"><?php echo esc_html( $type['mime'] ); ?></span>
									<?php if ( 'review' === $type['risk'] ) : ?>
										<span class="mimezone__badge"><?php esc_html_e( 'cleaned on upload', 'upload-anything' ); ?></span>
									<?php endif; ?>
								</label>
							<?php endforeach; ?>
						</div>
					</section>
				<?php endforeach; ?>

				<h2 class="mimezone__heading"><?php esc_html_e( 'Custom types', 'upload-anything' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'One entry per line, either the extension alone or "extension: mime/type". A type without a mime type is stored as application/octet-stream.', 'upload-anything' ); ?>
				</p>
				<textarea
					name="<?php echo esc_attr( Options::OPTION ); ?>[custom_types]"
					rows="4"
					class="large-text code"
					spellcheck="false"
				><?php echo esc_textarea( $custom ); ?></textarea>

				<p class="mimezone__blocked">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: comma separated list of file extensions. */
							__( 'Never unlocked: %s. These run on the server or change its configuration, so they are refused even in trusted mode.', 'upload-anything' ),
							'.' . implode( ', .', File_Types::BLOCKED )
						)
					);
					?>
				</p>

				<p class="mimezone__blocked mimezone__blocked--markup">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: comma separated list of file extensions. */
							__( 'Also refused, because a browser runs them as code instead of offering them as a download: %s.', 'upload-anything' ),
							'.' . implode( ', .', File_Types::LIVE_MARKUP )
						)
					);
					?>
				</p>

				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Capability choices, keyed by capability.
	 *
	 * The capabilities are ordered from strictest to loosest because that is how
	 * they read in the select.
	 *
	 * @return array<string, string>
	 */
	private function capability_choices() {
		return array(
			'manage_options'    => __( 'Administrators only', 'upload-anything' ),
			'edit_others_posts' => __( 'Editors and administrators', 'upload-anything' ),
			'upload_files'      => __( 'Anyone who can upload files', 'upload-anything' ),
		);
	}
}
