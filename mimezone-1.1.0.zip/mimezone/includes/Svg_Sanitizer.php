<?php
/**
 * SVG sanitizing.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ext-dom's property names are camelCase by definition, so the WordPress
// naming sniff cannot be satisfied without abandoning the DOM API.
// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

/**
 * Reduces an uploaded SVG to the subset that is safe to serve from the site.
 *
 * An SVG is an XML document, so it can carry script, event handler attributes
 * and references to remote content. Nothing here tries to be a full SVG
 * implementation: elements outside the drawing subset are dropped with their
 * subtree, URL attributes have to point at the file itself or at an embedded
 * raster image, and CSS that can execute or import is removed.
 *
 * `sanitize()` returns null when a document cannot be cleaned safely, which the
 * upload handler turns into a rejected upload rather than a best-effort file.
 */
final class Svg_Sanitizer {

	/**
	 * SVG namespace.
	 *
	 * @var string
	 */
	const NS = 'http://www.w3.org/2000/svg';

	/**
	 * Default size ceiling in bytes.
	 *
	 * @var int
	 */
	const MAX_BYTES = 2097152;

	/**
	 * Elements that survive, in their exact SVG spelling.
	 *
	 * The animate, set, foreignObject, script and HTML embedding elements are
	 * deliberately absent: they can rewrite attributes at runtime or pull in
	 * markup the browser treats as HTML.
	 *
	 * @var string[]
	 */
	const ALLOWED_ELEMENTS = array(
		'svg',
		'g',
		'defs',
		'symbol',
		'use',
		'a',
		'switch',
		'view',
		'path',
		'rect',
		'circle',
		'ellipse',
		'line',
		'polyline',
		'polygon',
		'text',
		'tspan',
		'textPath',
		'title',
		'desc',
		'style',
		'image',
		'linearGradient',
		'radialGradient',
		'stop',
		'clipPath',
		'mask',
		'pattern',
		'marker',
		'filter',
		'feBlend',
		'feColorMatrix',
		'feComponentTransfer',
		'feComposite',
		'feConvolveMatrix',
		'feDiffuseLighting',
		'feDisplacementMap',
		'feDistantLight',
		'feDropShadow',
		'feFlood',
		'feFuncA',
		'feFuncB',
		'feFuncG',
		'feFuncR',
		'feGaussianBlur',
		'feMerge',
		'feMergeNode',
		'feMorphology',
		'feOffset',
		'fePointLight',
		'feSpecularLighting',
		'feSpotLight',
		'feTile',
		'feTurbulence',
	);

	/**
	 * Clean an SVG document.
	 *
	 * @param string $contents Raw file contents.
	 * @return string|null Sanitized markup, or null when the file is not a
	 *                     cleanable SVG.
	 */
	public function sanitize( $contents ) {
		if ( ! is_string( $contents ) ) {
			return null;
		}

		$contents = trim( $contents );

		if ( '' === $contents || strlen( $contents ) > $this->max_bytes() ) {
			return null;
		}

		// Entity definitions are never needed by a drawing and are the payload
		// for both XXE and expansion attacks.
		if ( preg_match( '/<!\s*(?:ENTITY|DOCTYPE[^>]*\[)/i', $contents ) ) {
			return null;
		}

		$document = new \DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$loaded   = $document->loadXML( $contents, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_COMPACT );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		if ( ! $loaded || ! $document->documentElement instanceof \DOMElement ) {
			return null;
		}

		$root = $document->documentElement;

		if ( 'svg' !== $root->localName ) {
			return null;
		}

		if ( null !== $root->namespaceURI && self::NS !== $root->namespaceURI ) {
			return null;
		}

		if ( $document->doctype instanceof \DOMDocumentType ) {
			$document->removeChild( $document->doctype );
		}

		$this->clean_children( $root );

		if ( null === $root->namespaceURI ) {
			$root->setAttributeNS( 'http://www.w3.org/2000/xmlns/', 'xmlns', self::NS );
		}

		$clean = $document->saveXML( $root );

		if ( ! is_string( $clean ) || '' === trim( $clean ) ) {
			return null;
		}

		return trim( $clean ) . "\n";
	}

	/**
	 * Size limit for sanitizing, filterable for unusually large artwork.
	 *
	 * @return int
	 */
	private function max_bytes() {
		$limit = (int) apply_filters( 'mimezone_svg_max_bytes', self::MAX_BYTES );

		return $limit > 0 ? $limit : self::MAX_BYTES;
	}

	/**
	 * Walk and clean a node's children.
	 *
	 * @param \DOMNode $node Parent node.
	 * @return void
	 */
	private function clean_children( \DOMNode $node ) {
		$child = $node->firstChild;

		while ( $child ) {
			$next = $child->nextSibling;

			if ( $child instanceof \DOMElement ) {
				if ( ! in_array( $child->localName, self::ALLOWED_ELEMENTS, true ) ) {
					$node->removeChild( $child );
				} elseif ( ! $this->clean_element( $child ) ) {
					$node->removeChild( $child );
				} else {
					$this->clean_children( $child );
				}
			} elseif ( $child instanceof \DOMComment || $child instanceof \DOMProcessingInstruction ) {
				$node->removeChild( $child );
			}

			$child = $next;
		}
	}

	/**
	 * Clean one element's attributes and, for <style>, its contents.
	 *
	 * @param \DOMElement $element Element to clean.
	 * @return bool False when the element as a whole has to go.
	 */
	private function clean_element( \DOMElement $element ) {
		if ( 'style' === $element->localName ) {
			$css = $this->clean_css( $element->textContent );

			if ( null === $css ) {
				return false;
			}

			$element->textContent = $css;

			return true;
		}

		$names = array();

		foreach ( $element->attributes as $attribute ) {
			$names[] = $attribute->nodeName;
		}

		foreach ( $names as $name ) {
			$attribute = $element->getAttributeNode( $name );

			if ( ! $attribute instanceof \DOMAttr ) {
				continue;
			}

			$local = strtolower( (string) $attribute->localName );
			$value = (string) $attribute->value;

			if ( 0 === strpos( $local, 'on' ) ) {
				$element->removeAttributeNode( $attribute );
				continue;
			}

			if ( 'style' === $local ) {
				$css = $this->clean_css( $value );

				if ( null === $css ) {
					$element->removeAttributeNode( $attribute );
				} else {
					$element->setAttribute( $name, $css );
				}

				continue;
			}

			if ( in_array( $local, array( 'href', 'src' ), true ) && ! $this->is_safe_url( $value ) ) {
				$element->removeAttributeNode( $attribute );
			}
		}

		return true;
	}

	/**
	 * Reject CSS that can execute code or fetch a remote resource.
	 *
	 * @param string $css Declaration block or stylesheet body.
	 * @return string|null Null when the text cannot be made safe.
	 */
	private function clean_css( $css ) {
		$css = (string) $css;

		if ( '' === trim( $css ) ) {
			return $css;
		}

		if ( preg_match( '/expression\s*\(|javascript\s*:|vbscript\s*:|behavior\s*:|@import|image-set\s*\(/i', $css ) ) {
			return null;
		}

		// A literal angle bracket can end a style element early once the file is
		// served as text/html.
		if ( false !== strpos( $css, '<' ) ) {
			return null;
		}

		if ( preg_match_all( '/url\(\s*([\'"]?)([^\'")]*)\1\s*\)/i', $css, $matches ) ) {
			foreach ( $matches[2] as $url ) {
				if ( ! $this->is_safe_url( $url ) ) {
					return null;
				}
			}
		}

		return $css;
	}

	/**
	 * Whether a URL attribute or CSS url() may stay.
	 *
	 * Only same-document references, relative paths and embedded raster images
	 * are kept. Absolute URLs are dropped too: an upload should not be able to
	 * pull content from, or leak the visitor to, a third party.
	 *
	 * @param string $url Raw value.
	 * @return bool
	 */
	private function is_safe_url( $url ) {
		$url = (string) $url;

		// Control characters and entities are a common way to disguise a scheme.
		$url = preg_replace( '/[\x00-\x20\x7f]+/', '', $url );
		$url = trim( (string) $url );

		if ( '' === $url ) {
			return true;
		}

		if ( 0 === strpos( $url, '#' ) ) {
			return true;
		}

		if ( preg_match( '/^data:/i', $url ) ) {
			return (bool) preg_match( '#^data:image/(?:png|jpe?g|gif|webp);base64,#i', $url );
		}

		if ( preg_match( '/^[a-z][a-z0-9+.\-]*:/i', $url ) ) {
			return false;
		}

		if ( 0 === strpos( $url, '//' ) ) {
			return false;
		}

		return true;
	}
}

// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
