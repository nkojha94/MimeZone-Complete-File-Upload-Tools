<?php
/**
 * Upload handling.
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Teaches WordPress about the extra file types.
 *
 * Two filters are involved. `upload_mimes` adds the extensions to the allow
 * list, and `wp_check_filetype_and_ext` fills in the extension and mime type
 * when the file type sniffer comes back empty — which it does for most fonts,
 * archives and design files, and often for AVIF. Both are limited to the users
 * the settings page allows.
 */
final class Uploads {

	/**
	 * Byte-level types that are never accepted, whatever the file is named.
	 *
	 * Renaming a script to .avif should not get it past the extension check, so
	 * finfo's verdict is consulted before the name is trusted. Markup is on the
	 * list for the same reason: a page saved as .json is still a page.
	 *
	 * @var string[]
	 */
	const REFUSED_MIMES = array(
		'text/x-php',
		'application/x-php',
		'application/x-httpd-php',
		'application/x-httpd-php-source',
		'text/x-shellscript',
		'application/x-shellscript',
		'application/x-executable',
		'application/x-dosexec',
		'application/x-msdownload',
		'application/x-sharedlib',
		'application/x-mach-binary',
		'application/java-archive',
		'text/html',
		'application/xhtml+xml',
		'text/javascript',
		'application/javascript',
		'application/ecmascript',
		'text/css',
		'application/xml',
		'text/xml',
	);

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function register() {
		add_filter( 'upload_mimes', array( $this, 'allow_mimes' ) );
		add_filter( 'wp_check_filetype_and_ext', array( $this, 'check_filetype' ), 10, 5 );
		add_filter( 'wp_handle_upload_prefilter', array( $this, 'sanitize_upload' ) );
		add_filter( 'wp_handle_sideload_prefilter', array( $this, 'sanitize_upload' ) );
	}

	/**
	 * Add the enabled extensions to the allow list.
	 *
	 * @param array<string, string> $mimes Allowed types, keyed by extension.
	 * @return array<string, string>
	 */
	public function allow_mimes( $mimes ) {
		$mimes = is_array( $mimes ) ? $mimes : array();

		foreach ( Options::types_for_current_user() as $extension ) {
			$mime = File_Types::mime( $extension );

			if ( '' !== $mime ) {
				$mimes[ $extension ] = $mime;
			}
		}

		return $mimes;
	}

	/**
	 * Fill in the type when the sniffer could not identify the file.
	 *
	 * WordPress runs the real mime type through finfo, which knows fonts and
	 * archives only by accident. When it comes back with nothing, the extension
	 * is taken at face value — but only for extensions the settings allow.
	 *
	 * @param array<string, mixed> $data      File type data with ext, type and proper_filename.
	 * @param string               $file      Full path to the uploaded file.
	 * @param string               $filename  Original file name.
	 * @param array|null           $mimes     Allowed types, when called from core.
	 * @param string|null          $real_mime Mime type reported by finfo.
	 * @return array<string, mixed>
	 */
	public function check_filetype( $data, $file, $filename, $mimes = null, $real_mime = null ) {
		unset( $file, $mimes );

		if ( ! is_array( $data ) ) {
			return $data;
		}

		if ( is_string( $real_mime ) && in_array( strtolower( $real_mime ), self::REFUSED_MIMES, true ) ) {
			return $data;
		}

		$extension = self::extension_of( $filename );

		if ( ! Options::can_upload( $extension ) ) {
			return $data;
		}

		$mime = File_Types::mime( $extension );

		if ( '' === $mime ) {
			$mime = 'application/octet-stream';
		}

		// Core already has a usable answer, so leave its verdict alone.
		if ( ! empty( $data['ext'] ) && ! empty( $data['type'] ) ) {
			return $data;
		}

		$data['ext']             = $extension;
		$data['type']            = $mime;
		$data['proper_filename'] = false;

		return $data;
	}

	/**
	 * Sanitize an SVG before WordPress moves it into the uploads directory.
	 *
	 * @param array<string, mixed> $file Entry from $_FILES, with tmp_name, name and error.
	 * @return array<string, mixed>
	 */
	public function sanitize_upload( $file ) {
		if ( ! is_array( $file ) || ! empty( $file['error'] ) ) {
			return $file;
		}

		$name = isset( $file['name'] ) ? $file['name'] : '';

		if ( 'svg' !== self::extension_of( $name ) ) {
			return $file;
		}

		if ( ! Options::can_upload( 'svg' ) ) {
			return $file;
		}

		/**
		 * Short-circuit SVG sanitizing.
		 *
		 * Returning false stores the file exactly as uploaded. Only do that if
		 * something else in the stack cleans SVGs already.
		 *
		 * @param bool                 $sanitize Whether to sanitize.
		 * @param array<string, mixed> $file     Upload entry.
		 */
		if ( ! apply_filters( 'mimezone_sanitize_svg', true, $file ) ) {
			return $file;
		}

		$path = isset( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';

		if ( '' === $path || ! is_readable( $path ) ) {
			$file['error'] = __( 'The SVG file could not be read, so it was not uploaded.', 'upload-anything' );

			return $file;
		}

		$contents = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reading the temporary upload, not a remote URL.

		if ( false === $contents ) {
			$file['error'] = __( 'The SVG file could not be read, so it was not uploaded.', 'upload-anything' );

			return $file;
		}

		$clean = ( new Svg_Sanitizer() )->sanitize( $contents );

		if ( null === $clean ) {
			$file['error'] = __( 'This SVG could not be cleaned safely and was rejected. Re-export it from your editor and try again.', 'upload-anything' );

			return $file;
		}

		if ( $clean !== $contents ) {
			file_put_contents( $path, $clean ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Writing the sanitized copy over the temporary upload.
		}

		return $file;
	}

	/**
	 * Lowercase extension of a file name.
	 *
	 * @param string $filename File name.
	 * @return string Empty string when there is no usable extension.
	 */
	private static function extension_of( $filename ) {
		$extension = strtolower( (string) pathinfo( (string) $filename, PATHINFO_EXTENSION ) );

		return (string) preg_replace( '/[^a-z0-9]/', '', $extension );
	}
}
