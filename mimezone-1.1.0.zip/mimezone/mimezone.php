<?php
/**
 * Plugin Name:       MimeZone – Complete File Upload Tools
 * Plugin URI:        https://profiles.wordpress.org/nkojha/
 * Description:       Unlock SVG, AVIF, WebP, HEIC, fonts, archives and dozens of other file types WordPress blocks — with SVG cleaning built in.
 * Version:           1.1.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            NkOjha
 * Author URI:        https://github.com/nkojha94
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       upload-anything
 * Domain Path:       /languages
 *
 * @package MimeZone
 */

namespace MimeZone;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MIMEZONE_VERSION', '1.1.0' );
define( 'MIMEZONE_FILE', __FILE__ );
define( 'MIMEZONE_DIR', plugin_dir_path( __FILE__ ) );
define( 'MIMEZONE_URL', plugin_dir_url( __FILE__ ) );

/**
 * Load the plugin's classes.
 *
 * The plugin is distributed without a Composer vendor directory, so this keeps
 * the class map available on any site. Composer's autoloader, when present,
 * resolves the same names first and this callback never runs for them.
 *
 * @param string $class_name Fully qualified class name.
 * @return void
 */
spl_autoload_register(
	static function ( $class_name ) {
		$prefix = __NAMESPACE__ . '\\';

		if ( 0 !== strpos( $class_name, $prefix ) ) {
			return;
		}

		$relative = substr( $class_name, strlen( $prefix ) );
		$path     = MIMEZONE_DIR . 'includes/' . str_replace( '\\', '/', $relative ) . '.php';

		if ( is_readable( $path ) ) {
			require_once $path;
		}
	}
);

register_activation_hook( MIMEZONE_FILE, array( Installer::class, 'activate' ) );

add_action(
	'plugins_loaded',
	static function () {
		Plugin::instance()->boot();
	}
);
