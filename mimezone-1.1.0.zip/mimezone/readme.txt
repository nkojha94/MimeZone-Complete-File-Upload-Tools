=== MimeZone – Complete File Upload Tools ===
Contributors: nkojha
Tags: uploads, media, svg, avif, file types
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Unlock SVG, AVIF, WebP, HEIC, fonts, archives and dozens more file types WordPress blocks — with SVG cleaning built in.

== Description ==

WordPress ships with a short allow list of uploadable file types. Everything
outside it is rejected with "Sorry, you are not allowed to upload this file
type", which is why clients keep sending SVGs, fonts and design files that
nobody can upload.

MimeZone extends that list, and it treats the list as a decision rather than a
switch:

* 62 types across images, documents, archives, audio, video, fonts, design
  files and plain data.
* Per-type checkboxes, so the site unlocks what it needs and nothing else.
* A capability setting that decides whether editors or only administrators may
  use the extra types.
* A search box and bulk select for the catalogue, so finding `.heic` among
  sixty-odd rows takes a keystroke rather than a scroll.
* Trusted mode for the formats nobody predicted, available to administrators
  and still bounded by a hard deny list.

SVG uploads are cleaned on the way in. Script elements, event handler
attributes, remote references and executable CSS are removed before the file
reaches the uploads directory, and a file that cannot be cleaned is rejected
instead of stored. The media library then shows the file as an image rather
than as a generic attachment.

The plugin also refuses anything a browser would run as live markup. HTML,
JavaScript, CSS and XML are not in the catalogue at all — not off by default,
not administrator-only, simply absent — because a stored file that the front
end executes is an XSS vector regardless of who uploaded it. Each accepted file
is checked twice: once by extension, and once by the byte-level type of the
file itself, so renaming a script to `.avif` does not get it through.

Executable and server-configuring extensions are locked in code, not in
settings: `.php`, `.phtml`, `.phar`, `.exe`, `.htaccess`, `.env`, `.sql` and the
rest are filtered out before `upload_mimes` is called, so a tampered option
cannot bring them back.

= Works with =

* The media library, the block editor, the classic editor and
  `wp_handle_sideload()` (imports, remote images, theme and plugin installers).
* Multisite: the option is per site, and uninstalling clears it on every site.
* WP-CLI, for sites that configure uploads in a deploy script.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`, or install the zip from
   Plugins → Add New → Upload Plugin.
2. Activate the plugin.
3. Open Settings → MimeZone and choose the file types you want.

The defaults cover SVG, AVIF, WebP, HEIC, common font formats, a few audio and
video formats, archives and JSON/Markdown, so a fresh install solves the usual
"my client cannot upload this" ticket without touching a setting.

== Frequently Asked Questions ==

= Is it safe to allow SVG uploads? =

An SVG is an XML document and can carry script, so it is cleaned before it is
stored: unknown elements are dropped, `on*` attributes are removed, URL
attributes may only point inside the file or at an embedded raster image, and
CSS containing `expression()`, `@import` or a remote `url()` is stripped. Files
containing entity definitions, or that cannot be parsed, are refused.

If the site already runs an SVG sanitizer in its stack, add
`add_filter( 'mimezone_sanitize_svg', '__return_false' );` and this plugin will
store SVGs untouched.

= My file is still rejected. Why? =

Three things can still block an upload: the type is not selected on the
settings screen, the current user does not have the capability the settings
require, or the extension is on the deny list. Administrators can switch on
trusted mode to accept unknown extensions without turning off the deny list.

= Can I upload HTML, JavaScript or CSS? =

No, by design. Those types are served back by the browser as code, and a single
uploaded file would be enough to run script in an administrator's session.
There is no setting, filter or command that adds them.

= Does it work on multisite? =

Yes. Network-activate it and configure each site separately; the option is
per-site. Uninstalling removes the option from every site in the network.

= Are existing uploads changed? =

No. The plugin only filters new uploads, and SVG cleaning only touches files as
they are uploaded.

= Which types can never be enabled? =

Anything a web server can execute or use to change its own configuration: PHP
and its variants, CGI, Perl, Python, shell scripts, executables and shared
libraries, ASP/JSP, `php.ini`/`.env`, `.htaccess` and SQL dumps. The same goes
for markup a browser runs as code: HTML, XHTML, JavaScript, CSS, XML and
stylesheets. Both lists are shown at the bottom of the settings screen, and both
are enforced before any setting is read.

= What about the command line? =

```
wp mimezone status
wp mimezone types --enabled
wp mimezone enable svg avif jxl
wp mimezone disable svg
```

== Changelog ==

= 1.1.0 =
* Renamed to MimeZone: plugin name, folder, namespace and option key follow
  the new name. The text domain stays `upload-anything` because it has to match
  the wordpress.org slug.
* HTML, JavaScript, CSS and XML removed from the catalogue: browser-executed
  markup is no longer offered to any role.
* Plugin icon, banner and settings-screen mark added.
* Translation loading left to WordPress core.

= 1.0.0 =
* First release.
* 68 file types across eight groups, with per-type selection.
* Capability-scoped access to the extra types.
* SVG cleaning with an element and attribute allow list.
* Media library previews for SVG attachments.
* WP-CLI commands: `status`, `types`, `enable`, `disable`.

== Upgrade Notice ==

= 1.1.0 =
Renames the plugin to MimeZone and removes HTML, JavaScript, CSS and XML from
the catalogue.
