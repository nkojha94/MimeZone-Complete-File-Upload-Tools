<?php
/**
 * Uninstall routine.
 *
 * Only the option goes. Uploaded files stay in the media library, and the small
 * attachment meta entry that caches SVG dimensions is left behind because it
 * describes a file that still exists.
 *
 * @package MimeZone
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Keep in sync with Options::OPTION; the class is not loaded during uninstall.
$mimezone_option = 'mimezone_settings';

if ( is_multisite() ) {
	$mimezone_sites = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);

	foreach ( $mimezone_sites as $mimezone_site ) {
		switch_to_blog( (int) $mimezone_site );
		delete_option( $mimezone_option );
		restore_current_blog();
	}

	return;
}

delete_option( $mimezone_option );
